# -*-coding: utf-8 -*-

from datetime import datetime, timedelta

from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils.translation import ugettext_lazy as _

from django.contrib.auth.models import User

CIRCLE_ENTRY_STATUS = (
    ('spectator', _('Spectator')),
    ('favourite', _('Favourite')),
)

DISCUSSION_VISIBILITY = (
    ('private', _('Private')),
    ('public', _('Public')),
)


def dicom_uploader(instance, filename):
    return 'dicom/%s/%s-%s' % (instance.owner.id, datetime.now().strftime('%Y-%m-%d-%H-%M-%S'), filename)


def after_two_weeks():
    return datetime.now() + timedelta(days=14)


class Expert(models.Model):

    user = models.OneToOneField(User, related_name='expert')
    first_name = models.CharField(max_length=255, blank=True)
    second_name = models.CharField(max_length=255, blank=True)
    last_name = models.CharField(max_length=255, blank=True)
    contact_list = models.ManyToManyField('self',  blank=True)
    place_of_work = models.CharField(max_length=500, default='', blank=False)  # Может быть пустым?
    degree = models.CharField(max_length=255, default='', blank=False)  # Справочник?
    post = models.CharField(max_length=255, default='', blank=False)
    speciality = models.CharField(max_length=255, blank=False)  # Справочник?
    email = models.EmailField(blank=False, null=False)
    phone = models.CharField(max_length=16, null=True, blank=True)
    is_private_phone = models.BooleanField(default=True)

    registration_key = models.CharField(max_length=64, default='', blank=True)

    def _get_name(self):
        name = u'%s %s' % (self.first_name or u'', self.last_name or u'')
        if name.strip():
            return name
        return u'user #%s' % self.id

    name = property(_get_name)

    class Meta:
        verbose_name = "Expert"
        verbose_name_plural = "Experts"

    def __str__(self):
        return self.name

    def __unicode__(self):
        return unicode(self.name)


class Dicom(models.Model):
    WAITING     = 1
    PREPARING   = 2
    READY       = 3
    OBSOLETE    = 4
    STATUS_CHOICES = (
        (WAITING,   'Waiting'),
        (PREPARING, 'Preparing'),
        (READY,     'Ready'),
        (OBSOLETE,  'Obsolete'),
    )

    MALE = 1
    FEMALE = 2
    SEX_CHOICES = (
        (MALE, 'M'),
        (FEMALE, 'F'),
    )

    owner               = models.ForeignKey('Expert', related_name='dicoms')
    patient_id          = models.IntegerField(null=True, blank=True)
    patient_name        = models.CharField(max_length=512, null=True, blank=True)
    patient_sex         = models.CharField(max_length=1, null=True, blank=True)
    patient_birthday    = models.DateField(null=True, blank=True)
    patient_age         = models.CharField(max_length=7, null=True, blank=True)
    patient_weight      = models.IntegerField(null=True, blank=True)
    study_date          = models.DateField(null=True, blank=True)
    description         = models.TextField(blank=True)
    downloadable        = models.BooleanField(default=False)
    file                = models.FileField(upload_to=dicom_uploader)
    status              = models.IntegerField(_('Status'), choices=STATUS_CHOICES, default=WAITING)
    created_at          = models.DateField(_('Created'), auto_now=True)
    end_date            = models.DateField(default=after_two_weeks)

    def __get_default_image(self):
        myFiles = DicomFile.objects.filter(dicom=self)
        if myFiles.exists():
            return myFiles[0].file.url
        else:
            return 'http://otolor.ru/images/exx_04.jpg'

    default_image = property(__get_default_image)

    class Meta:
        verbose_name = "Dicom"
        verbose_name_plural = "Dicoms"

    def __unicode__(self):
        return u'%s, %s' % (self.patient_name, self.description)


class DicomFile(models.Model):
    dicom               = models.ForeignKey(Dicom, related_name='files')
    file                = models.FileField()
    orientation         = models.CharField(max_length=255, blank=True, null=True)
    series_description  = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        verbose_name = "Dicom Extracted File"
        verbose_name_plural = "Dicom Exctracted Files"


class Transfer(models.Model):
    NEW = 1
    ACCEPTED = 2
    DECLINED = 3
    STATUS_CHOICES = (
        (NEW, 'New'),
        (ACCEPTED, 'Accepted'),
        (DECLINED, 'Declined'),
    )

    sender      = models.ForeignKey(Expert, related_name='sent_transfers')
    recipient   = models.ForeignKey(Expert, related_name='received_transfers')
    description = models.TextField(blank=True)
    dicoms      = models.ManyToManyField('Dicom')
    status      = models.IntegerField(_('Status'), choices=STATUS_CHOICES, default=NEW)
    created_at  = models.DateField(_('Created'), auto_now=True)
    code        = models.CharField(max_length=64, default='', blank=True)

    def __unicode__(self):
        return u"%s transfers %s dicoms to %s" % (self.sender, len(self.dicoms.all()), self.recipient)


class Discussion(models.Model):
    owner = models.ForeignKey(Expert, related_name='discussions')
    name = models.CharField(max_length=255, blank=False)
    description = models.TextField(blank=True)
    dicoms = models.ManyToManyField('Dicom')
    created_at = models.DateField(_('Created'), auto_now=True)
    closed_at = models.DateField(_('Closed'), blank=True, null=True)
    end_date = models.DateField(default=after_two_weeks)
    visibility = models.CharField(choices=DISCUSSION_VISIBILITY, max_length=8)

    @property
    def sorted_comments(self):
        return self.comments.order_by('-commented_at')

    @property
    def comment_count(self):
        return self.comments.count()

    def _get_status(self):
        if self.closed_at:
            return "closed"
        elif self.end_date < datetime.now():
            return "expired"
        else:
            return "open"

    status = property(_get_status)

    class Meta:
        verbose_name = "Discussion"
        verbose_name_plural = "Discussions"
        permissions = (
            ("can_manage", "Can manage a discussion"),
            ("can_view", "Can view a discussion"),
            ("can_comment", "Can comment a discussion"),
        )

    def __unicode__(self):
        return self.name


class Participant(models.Model):
    expert = models.ForeignKey(Expert)
    discussion = models.ForeignKey(Discussion)
    joined_at = models.DateTimeField(_('Joined'), auto_now=True)
    left_at = models.DateTimeField(_('Left'), blank=True, null=True)
    is_interesting = models.BooleanField(default=False)

    def _is_joined(self):
        return self.left_at is None

    is_joined = property(_is_joined)

    def __unicode__(self):
        return u"%s at %s" % (self.expert, self.discussion)


class Comment(models.Model):
    author = models.ForeignKey(Expert, related_name='comments')
    discussion = models.ForeignKey(Discussion, related_name='comments')
    parent = models.ForeignKey('Comment', blank=True, null=True, related_name='children')
    text = models.TextField(_('Text'))
    commented_at = models.DateTimeField(_('Commented'), auto_now=True)

    def __unicode__(self):
        return u"%s commented %s at %s" % (self.author, self.discussion, self.commented_at)


class Invite(models.Model):
    NEW = 1
    ACCEPTED = 2
    DECLINED = 3
    STATUS_CHOICES = (
        (NEW, 'New'),
        (ACCEPTED, 'Accepted'),
        (DECLINED, 'Declined'),
    )

    initiator  = models.ForeignKey(Expert, verbose_name=_('Initiator'), related_name='sent_invites')
    invitee    = models.ForeignKey(Expert, verbose_name=_('Invitee'), related_name='received_invites')
    discussion = models.ForeignKey(Discussion, verbose_name=_('Discussion'))
    invited_at = models.DateTimeField(_('Invited at'), auto_now=True)
    decided_at = models.DateTimeField(_('Decided at'), blank=True, null=True)
    status     = models.IntegerField(_('Status'), choices=STATUS_CHOICES, default=NEW)
    code       = models.CharField(max_length=64, default='', blank=True)

    def __unicode__(self):
        return u"%s invites %s to %s" % (self.initiator, self.invitee, self.discussion)


class Notification(models.Model):
    TRANSFER_RECEIVED = 1
    TRANSFER_ACCEPTED = 2
    TRANSFER_DECLINED = 3
    TYPE_CHOICES = (
        (TRANSFER_RECEIVED, 'Transfer received'),
        (TRANSFER_ACCEPTED, 'Transfer accepted'),
        (TRANSFER_DECLINED, 'Transfer declined'),
    )

    NEW = 1
    READ = 2
    HIDDEN = 3
    STATUS_CHOICES = (
        (NEW, 1),
        (READ, 2),
        (HIDDEN, 3),
    )

    owner       = models.ForeignKey(Expert, related_name='notifications')
    type        = models.IntegerField(_('Type'), choices=TYPE_CHOICES)
    status      = models.IntegerField(_('Status'), choices=STATUS_CHOICES, default=NEW)
    transfer    = models.ForeignKey(Transfer, verbose_name=_('Transfer'), blank=True, null=True)
    created_at  = models.DateField(_('Created'), auto_now=True)

    class Meta:
        verbose_name = "Notification"
        verbose_name_plural = "Notifications"

    def __unicode__(self):
        pass


@receiver(post_save, sender=User)
def create_user(sender, instance, created, **kwargs):
    user = instance
    if created:
        registration_key = User.objects.make_random_password(
            length=32, allowed_chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789')
        Expert.objects.create(user=user, registration_key=registration_key,
            first_name=user.first_name, last_name=user.last_name, email=user.email)
