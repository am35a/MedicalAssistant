function supportWheel(app) {
    app.directive('ngMouseWheel', function() {
        return function(scope, element, attrs) {
            var handler = scope.$eval(attrs.ngMouseWheel);
            element.bind("DOMMouseScroll mousewheel onmousewheel", function(event) {
                // cross-browser wheel delta
                var event = window.event || event.originalEvent || event; // old IE support
                var delta = Math.max(-1, Math.min(1, (event.wheelDelta || -event.detail)));

                scope.$apply(function() { handler(delta); });

                // for IE
                event.returnValue = false;
                // for Chrome and Firefox
                if (event.preventDefault) {
                    event.preventDefault();
                }
            });
        };
    });
}
