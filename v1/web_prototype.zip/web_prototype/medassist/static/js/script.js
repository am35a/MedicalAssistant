//var anchor = window.location.hash.substring(1);
//
//function removeIsActive() {
//    $("#a-tab-enter,#a-tab-registration,#a-tab-forgot").removeClass('is-active');
//    $("#fixed-tab-1,#fixed-tab-2,#fixed-tab-3").removeClass('is-active');
//}
//
// $(document).ready(function(){
//    switch (anchor) {
//        case "registration":
//            removeIsActive()
//            $("#a-tab-registration,#fixed-tab-2").addClass('is-active');
//            break;
//    }
//
//})
