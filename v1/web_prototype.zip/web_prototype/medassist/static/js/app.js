//
// API
//

angular.module('medassist.api', ['ngResource', 'ngFileUpload'])
    .factory('Dicom', ['$resource',
        function ($resource) {
            return $resource('/api/dicoms/:id', null, {'change': { method:'PUT' }});
        }
    ])
    .factory('DicomFile', ['$resource',
        function ($resource) {
            return $resource('/api/dicom_files/:id', null, {'change': { method:'PUT' }});
        }
    ])
    .factory('Discussion', ['$resource',
        function ($resource) {
            return $resource('/api/discussions/:id', null, {'change': { method:'PUT' }});
        }
    ])
    .factory('Comment', ['$resource',
        function ($resource) {
            return $resource('/api/comments/:id', null, {'change': { method:'PUT' }});
        }
    ])
    .factory('Transfer', ['$resource',
        function ($resource) {
            return $resource('/api/transfers/:id', null, {'change': { method:'PUT' }});
        }
    ])
    .factory('Notification', ['$resource',
        function ($resource) {
            return $resource('/api/notifications/:id', null, {'change': { method:'PUT' }});
        }
    ])
;

//
// Controllers
//

angular.module('medassist.controllers', ['medassist.api', 'ngRoute']).
    controller('DiscussionListController',
        ['$scope', 'Discussion',
        function ($scope, Discussion) {
            $scope.discussions = Discussion.query();
            $scope.$on('$viewContentLoaded', function () {
                componentHandler.upgradeAllRegistered();
            });
        }]
    ).
    controller('DiscussionViewController',
        ['$scope', '$routeParams', '$location', 'Comment', 'Discussion',
        // TODO: check if $routeParams.id is numeric
        function ($scope, $routeParams, $location, Comment, Discussion) {
            $scope.new_text = '';
            $scope.discussion = Discussion.get($routeParams);
            $scope.comments = Comment.query({'discussion_id': $routeParams.id})
            $scope.add_comment = function () {
                var comment = new Comment();
                comment.text = $scope.new_text;
                comment.discussion_id = $scope.discussion.id;
                comment.$save().then(
                    function (result) {
                        $scope.comments.push(result);
                    }
                );
                $scope.new_text = '';
            }
            $scope.$on('$viewContentLoaded', function () {
                componentHandler.upgradeAllRegistered();
            });
        }]
    ).
    controller('DiscussionDetailController',
        ['$scope', '$routeParams', '$location', 'Discussion',
        // TODO: check if $routeParams.id is numeric or 'new'
        function ($scope, $routeParams, $location, Discussion) {
            var isNew = $routeParams.id == "new";
            $scope.discussion = isNew ? new Discussion() : Discussion.get($routeParams);
            $scope.save = function () {
                if (isNew) {
                    $scope.discussion.$save().then(
                        function (result) {
                            $scope.discussions.push(result);
                            $location.path('/discussions');
                        });
                }
                else {
                    Discussion.change({'id': $scope.discussion.id}, $scope.discussion,
                        function () { $location.path('/discussions'); })
                }
            };
            $scope.$on('$viewContentLoaded', function () {
                componentHandler.upgradeAllRegistered();
            });
        }]
    ).
    controller('DiscussionDeleteController',
        ['$scope', '$routeParams', '$location', 'Discussion',
        // TODO: check if $routeParams.id is numeric
        function ($scope, $routeParams, $location, Discussion) {
            $scope.delete = function (discussion) {
                console.log(discussion);
                //discussion.$delete();
            };
        }]
    ).
    controller('TomographyListController',
        ['$scope', '$routeParams', '$location', '$http', 'Dicom', 'DicomFile',
        function ($scope, $routeParams, $location, $http, Dicom, DicomFile) {
            $scope.predicate = 'study_date';
            $scope.reverse = false;
            $scope.viewAsList = true;
            $scope.showView = false;
            $scope.mainImage = 'http://test.medassist.i1s.ru:81/static/dicom/4/50/DICOM/15060811/37580000/60607342.med.jpg';
            $scope.dicoms = Dicom.query();
            $scope.add_tomography = function () {
                $location.path('/tomographies/edit/new');
            };
            $scope.change_order = function () {
                $scope.reverse = !$scope.reverse;
            };
            $scope.change_view = function () {
                $scope.viewAsList = !$scope.viewAsList;
            };
            $scope.show_view = function (v, id) {
                $scope.showView = v;
                if (id) {
                    $scope.dicomId = id;
                    $http({
                        method: 'GET',
                        url: '/api/dicoms/' + id + '/series'
                    }).then(
                        function (resp) {
                            $scope.series = resp.data;
                            if ($scope.series.length > 0) {
                                $scope.select_serie($scope.series[0]);
                            }
                        },
                        function (resp) {}
                    );
                }
            };
            $scope.select_serie = function(serie) {
                for (var i = 0; i < $scope.series.length; i++) {
                    $scope.series[i].selected = false;
                }
                serie.selected = true;
                $scope.dicom_files = DicomFile.query(
                    {'dicom_id': $scope.dicomId, 'series_description': serie.name},
                    function () {
                        var len = $scope.dicom_files.length;
                        if (len > 0) {
                            $scope.dicom_index = Math.floor(len/2);
                            $scope.mainImage = $scope.dicom_files[$scope.dicom_index].url;
                        }
                    });
            };
            $scope.on_wheel = function(delta) {
                var len = $scope.dicom_files.length;
                var index = $scope.dicom_index;
                index += delta;
                if (index < 0 || index >= len) return;
                $scope.dicom_index = index;
                $scope.mainImage = $scope.dicom_files[$scope.dicom_index].url;
            };
            $scope.transfer = function(dicom) {
                $location.path('/tomographies/' + dicom.id + '/transfers/new');;
            };
            $scope.$on('$viewContentLoaded', function () {
                componentHandler.upgradeAllRegistered();
            });
        }]
    ).
    controller('TomographyDetailController',
        ['$scope', '$routeParams', '$location', 'Upload', 'Dicom',
        // TODO: check if $routeParams.id is numeric
        function ($scope, $routeParams, $location, Upload, Dicom) {
            $scope.dicom = new Dicom();
            $scope.post_dicom = function() {
                $scope.progress = true;
                $scope.errorText = "";
                Upload.upload({
                    url: '/api/dicoms',
                    method: 'POST',
                    data: {
                        patient_name: $scope.dicom.patient_name,
                        description: $scope.dicom.description,
                        file: $scope.file
                    }
                }).then(function (resp) {
                    $scope.progress = false;
                    $location.path('/tomographies');
                }, function (resp) {
                    $scope.progress = false;
                    $scope.errorText = resp.status;
                    if (resp.data) {
                        for (p in resp.data) {
                            text = resp.data[p][0];
                            if (text) {
                                $scope.errorText = text;
                                break;
                            }
                        }
                    }
                }, function (evt) {
                    var progress = parseInt(100.0 * evt.loaded / evt.total);
                    document.querySelector('#tomo_upload_progress').MaterialProgress.setProgress(progress);
                });
            };
            $scope.$on('$viewContentLoaded', function () {
                componentHandler.upgradeAllRegistered();
            });
        }]
    ).
    controller('TransferCreateController',
        ['$scope', '$routeParams', '$location', 'Transfer', 'Dicom',
        function($scope, $routeParams, $location, Transfer, Dicom) {
            console.log($routeParams);
            console.log($location);

            var recipient_email_el = window.document.getElementById('recipient_email');
//                if (recipient_email_el) recipient_email_el.focus();

            $scope.create_transfer = function() {
                console.log("SUBMIT");
                transfer = new Transfer({
                    dicoms: [$routeParams.dicom_id],
                    recipient_email: $scope.recipient_email
                });
                console.log(transfer);
                transfer.$save(function (e) { console.log(e); })
            };
            $scope.go_back = function() {
                history.back();
            };
            $scope.$on('$viewContentLoaded', function () {
                componentHandler.upgradeAllRegistered();
            });
        }]
    ).
    controller('NotificationListController',
        ['$scope', 'Notification',
            function ($scope, Notification) {
                $scope.notifications = Notification.query(function () {
                    console.log($scope.notifications);
                    angular.forEach($scope.notifications, function (notification) {
                        switch (notification.type) {
                            case 1:
                                notification.type_description = 'Transfer received';
                                notification.description = 'Transfer received';
                                break;
                            case 2:
                                notification.type_description = 'Transfer accepted';
                                notification.description = 'Transfer accepted';
                                break;
                            case 3:
                                notification.type_description = 'Transfer declined';
                                notification.description = 'Transfer declined';
                                break;
                        }
                    });
                });
            }]
    )
;

var medassistApp = angular.module('medassist', ['medassist.controllers', 'ngRoute']);
medassistApp.
    config(['$routeProvider',
        function ($routeProvider) {
            $routeProvider.
                when('/discussions', {
                    templateUrl: '/ui/discussion-list.html',
                    controller: 'DiscussionListController'
                }).
                when('/discussions/:id', {
                    templateUrl: '/ui/discussion-view.html',
                    controller: 'DiscussionViewController'
                }).
                when('/discussions/edit/:id', {
                    templateUrl: '/ui/discussion-detail.html',
                    controller: 'DiscussionDetailController'
                }).
                when('/tomographies', {
                    templateUrl: '/ui/tomo-list.html',
                    controller: 'TomographyListController'
                }).
                when('/tomographies/:id', {
                    templateUrl: '/ui/tomo-view.html',
                    controller: 'TomographyViewController'
                }).
                when('/tomographies/edit/:id', {
                    templateUrl: '/ui/tomo-detail.html',
                    controller: 'TomographyDetailController'
                }).
                when('/tomographies/:dicom_id/transfers/new', {
                    templateUrl: '/ui/tomo-transfer.html',
                    controller: 'TransferCreateController'
                }).
                when('/notifications', {
                    templateUrl: '/ui/notification-list.html',
                    controller: 'NotificationListController'
                }).
                otherwise({});
        }
    ]).
    config(['$httpProvider', function($httpProvider) {
        $httpProvider.defaults.xsrfCookieName = 'csrftoken';
        $httpProvider.defaults.xsrfHeaderName = 'X-CSRFToken';
    }]).
    filter('static_url', function() {
        return function(input) {
            if (input.lastIndexOf('http', 0) == 0) {
                return input;
            }
            return '/static/' + input;
        }
    }).
    directive('backImg', function() {
        return function(scope, element, attrs) {
            scope.$watch(attrs.backImg, function (url) {
                element.css('background-image', 'url("' + url +'")');
            });
        };
    }).
    directive('goBack', function() {
        return {
            link: function(scope, element, attrs) {
                element.on('click', function() {
                    window.history.back();
                });
            }
        };
    })
;

supportWheel(medassistApp);

angular.element(document).ready(function() { componentHandler.upgradeAllRegistered(); });
