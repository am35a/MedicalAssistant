//
// API
//

angular.module('medassist.change_password', []).
    config(['$httpProvider', function($httpProvider) {
        $httpProvider.defaults.xsrfCookieName = 'csrftoken';
        $httpProvider.defaults.xsrfHeaderName = 'X-CSRFToken';
    }]).
    directive('sameAs', function () {
        return {
            restrict: 'A',
            require: 'ngModel',
            scope: {
                sameValue: '=sameAs'
            },
            link: function (scope, elem, attr, ngModel) {
                ngModel.$validators.sameAs = function (value) {
                    var valid = value == scope.sameValue;
//                    ngModel.$setValidity('same-as', valid);
                    return valid;
//                    return valid ? value : undefined;
                };
                scope.$watch("sameValue", function() {
                    ngModel.$validate();
                });
            }
        };
    }).
    controller('ChangePasswordController',
        ['$scope', '$http',
        function ($scope, $http) {
            $scope.password1 = "";
            $scope.password2 = "";
            $scope.form_valid = function() {
                return (/^[^\s]+$/.test($scope.password1) &&
                    $scope.password1 == $scope.password2);
            };
            $scope.$on('$viewContentLoaded', function () {
                componentHandler.upgradeAllRegistered();
            });
        }]
    );

angular.element(document).ready(function() { componentHandler.upgradeAllRegistered(); });
