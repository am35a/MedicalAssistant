//
// API
//

var medassistApp = angular.module('medassist.login', []).
    config(['$httpProvider', function($httpProvider) {
        $httpProvider.defaults.xsrfCookieName = 'csrftoken';
        $httpProvider.defaults.xsrfHeaderName = 'X-CSRFToken';
    }]).
    controller('LoginController',
        ['$scope', '$http',
        function ($scope, $http) {
//            $scope.email = "";
//            $scope.password = "";
            $scope.error = null;
            $scope.login = function() {
                $scope.errors = {};
                $http.post("/api/user/login/", JSON.stringify({
                        username: $scope.email,
                        password: $scope.password
                    })).
                    then(function (result) {
                        if (result.data.success) {
                            window.location = window.location.protocol + "//" + window.location.host + "/my/", "_self";
                        }

                        $scope.error = result.data.error;
                    });
            };
            $scope.$on('$viewContentLoaded', function () {
//                componentHandler.upgradeAllRegistered();
            });
        }]
    ).
    controller('RegistrationController',
        ['$scope', '$http',
        function ($scope, $http) {
            $scope.email = "";
            $scope.first_name = "";
            $scope.last_name = "";
            $scope.registration_success = false;
            $scope.errors = {};
            $scope.register = function() {
                $scope.errors = {};
                $http.post("/api/user/register/", JSON.stringify({
                        email: $scope.email,
                        first_name: $scope.first_name,
                        last_name: $scope.last_name
                    })).
                    then(function (result) {
                        $scope.registration_success = result.data.success;
                        errors = {};
                        for (var p in result.data.errors) {
                            errors[p] = result.data.errors[p][0];
                        }
                        $scope.errors = errors;
                    });
            };
            $scope.done_click = function () {
                $scope.registration_success = false;
                // MDL specific code!
                $('#a-tab-enter span').click();
                $('#sign_up div').removeClass('is-dirty');
                $scope.email = "";
                $scope.first_name = "";
                $scope.last_name = "";
            };
            $scope.$on('$viewContentLoaded', function () {
//                componentHandler.upgradeAllRegistered();
            });
        }]
    ).
    controller('ForgotPassController',
        ['$scope', '$http',
        function ($scope, $http) {
            $scope.email_to_recover = "";
            $scope.reset_instruction_sent = false;
            $scope.reset_password = function () {
                $http.post("/api/password_reset/", JSON.stringify({email: $scope.email_to_recover})).
                    then(function (result) {
                        // MDL specific code!
                        $scope.reset_instruction_sent = true;
                    });
            };
            $scope.done_click = function () {
                // MDL specific code!
                $('#a-tab-enter span').click();
                $('#forgot div').removeClass('is-dirty');
                $scope.reset_instruction_sent = false;
                $scope.email_to_recover = "";
            };
            $scope.$on('$viewContentLoaded', function () {
//                componentHandler.upgradeAllRegistered();
            });
        }]
    );

//angular.element(document).ready(function() { componentHandler.upgradeAllRegistered(); });
medassistApp.run(['$rootScope', '$timeout', function($rootScope, $timeout) {
    $rootScope.$on('$viewContentLoaded', function(event) {
        $timeout(function() {
            componentHandler.upgradeAllRegistered();
        }, 0);
    });
    $rootScope.render = {
        header: true,
        aside: true
    }
}]);
