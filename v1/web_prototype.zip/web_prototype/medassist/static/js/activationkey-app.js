//
// API
//

angular.module('medassist.activation_key', []).
    config(['$httpProvider', function($httpProvider) {
        $httpProvider.defaults.xsrfCookieName = 'csrftoken';
        $httpProvider.defaults.xsrfHeaderName = 'X-CSRFToken';
    }]).
    controller('ActivationKeyController',
        ['$scope',
        function ($scope) {
            $scope.goto_cabinet = function () {
                window.location = window.location.protocol + "//" + window.location.host + "/my/", "_self";
            };
            $scope.goto_login = function () {
                window.location = window.location.protocol + "//" + window.location.host + "/", "_self";
            };
            $scope.$on('$viewContentLoaded', function () {
                componentHandler.upgradeAllRegistered();
            });
        }]
    );

angular.element(document).ready(function() { componentHandler.upgradeAllRegistered(); });
