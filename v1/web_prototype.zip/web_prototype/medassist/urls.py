from django.conf.urls import include, url
from django.contrib import admin, auth

from rest_framework import routers

from medassist import views


router = routers.DefaultRouter(trailing_slash=False)
router.register(r'comments', views.CommentViewSet, base_name='Comment')
router.register(r'dicoms', views.DicomViewSet, base_name='Dicom')
router.register(r'dicom_files', views.DicomFileViewSet, base_name='DicomFile')
router.register(r'transfers', views.TransferViewSet, base_name='Transfer')
router.register(r'notifications', views.NotificationViewSet, base_name='Notification')
router.register(r'discussions', views.DiscussionViewSet, base_name='Discussion')

urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    url(r'^$', views.do_index),
    url(r'^registration/', views.do_registration),
    url(r'^register/', views.do_register),
    url(r'^activate/(?P<activation_key>.*)', views.do_activate),
    url(r'^login/', views.do_login),
    url(r'^logout/', views.do_logout),

    url(r'^password/reset/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$',
        auth.views.password_reset_confirm, name='password_reset_confirm'),
    url(r'^password/reset/complete', views.password_reset_complete, name='password_reset_complete'),

    url(r'^my/', views.my_view),
    url(r'^ui/', views.my_view),

    url(r'^dicom/new/', views.dicom_new),
    url(r'^dicom/create/', views.dicom_create),
    url(r'^discussion/(\d+)$', views.discussion_view),
    url(r'^discussion/new/', views.discussion_new),
    url(r'^discussion/create/', views.discussion_create),
    url(r'^invite/new/', views.invite_new),
    url(r'^invite/create/', views.invite_create),
    url(r'^invite/accept/(?P<code>.*)', views.invite_accept),
    url(r'^invite/decline/(?P<code>.*)', views.invite_decline),
    url(r'^comment/create/', views.comment_create),
    url(r'^transfer/new/', views.transfer_new),
    url(r'^transfer/create/', views.transfer_create),
    url(r'^transfer/accept/(?P<code>.*)', views.transfer_accept),
    url(r'^transfer/decline/(?P<code>.*)', views.transfer_decline),

    url(r'^api/password_reset/$', views.api_reset_password),
    url(r'^api/user/register/$', views.api_user_register),
    url(r'^api/user/login/$', views.api_user_login),
    url(r'^api/dicoms/(\d+)/series$', views.api_dicom_series),
    url(r'^api/', include(router.urls, namespace='api')),
]
