from django import template

register = template.Library()


@register.simple_tag(takes_context=True)
def link(context, path_pattern, *args):
    return context['request'].build_absolute_uri(path_pattern % args)
