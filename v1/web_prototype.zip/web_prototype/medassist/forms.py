from django import forms
from django.conf import settings
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _

from .models import *
from .utils import send_mail_to_user


class RegistrationForm(forms.ModelForm):
    email = forms.EmailField(label=_("E-mail"), max_length=75)
    first_name  = forms.CharField(label=_("First name"), max_length=255, required=True)
    second_name = forms.CharField(label=_("Second name"), max_length=255, required=False)
    last_name = forms.CharField(label=_("Last name"), max_length=255, required=True)

    def __init__(self, request):
        super(RegistrationForm, self).__init__(request.data)
        self.request = request

    class Meta:
        model = User
        fields = ("email", 'first_name', 'last_name')

    def clean_email(self):
        email = self.cleaned_data["email"]

        try:
            User.objects.get(email__iexact=email)
        except User.DoesNotExist:
            return email.lower()

        raise forms.ValidationError(
            _("A user with such email already exists."), code='email_exists', params={'value': email})

    def save(self, commit=True):
        try:
            user = User.objects.get(email=self.cleaned_data["email"])
            send_mail_to_user(self.request, user, 'registration_exist')
            return user
        except User.DoesNotExist:
            pass

        user = super(RegistrationForm, self).save(commit=False)
        user.username = user.email
        user.set_password(User.objects.make_random_password(length=8))

        if commit:
            user.save()

            expert = user.expert
            expert.first_name  = self.cleaned_data['first_name']
            expert.second_name = self.cleaned_data['second_name']
            expert.last_name   = self.cleaned_data['last_name']

            expert.save()

            activation_url = settings.ACTIVATION_URL % (self.request.META['HTTP_HOST'], expert.registration_key)
            send_mail_to_user(self.request, user, 'activation_code', {'activation_url': activation_url})

        return user


class DicomForm(forms.ModelForm):
    def __init__(self, request):
        super(DicomForm, self).__init__(request and request.POST, request and request.FILES)
        self.request = request

    def save(self, commit=True):
        dicom = super(forms.ModelForm, self).save(commit=False)
        dicom.owner = self.request.user.expert
        if commit:
            dicom.save()
        return dicom

    class Meta:
        model = Dicom
        fields = ("description", "downloadable", "file")


class DiscussionForm(forms.ModelForm):
    def __init__(self, request):
        super(DiscussionForm, self).__init__(request and request.POST, request and request.FILES)
        self.request = request
        self.fields["dicoms"].queryset = Dicom.objects.filter(owner=request.user.expert)

    def clean(self):
        dicoms = self.cleaned_data.get("dicoms")
        if dicoms:
            for dicom in dicoms:
                if dicom.owner != self.request.user.expert:
                    raise ValidationError(_("Unknown dicom"))

    def save(self, commit=True):
        discussion = super(forms.ModelForm, self).save(commit=False)
        discussion.owner = self.request.user.expert
        if commit:
            discussion.save()
        return discussion

    class Meta:
        model = Discussion
        fields = ("name", "description", "dicoms", "visibility")


class InviteForm(forms.ModelForm):
    email = forms.EmailField(label=_("E-mail"), max_length=75)

    def __init__(self, request):
        super(InviteForm, self).__init__(request and request.POST)
        self.request = request

    def clean_discussion(self):
        discussion = self.cleaned_data["discussion"]
        if discussion.owner != self.request.user.expert:
            raise forms.ValidationError('Discussion does not belong to the logged user')

        return discussion

    def save(self, commit=True):
        email = self.cleaned_data["email"]
        try:
            invitee_user = User.objects.get(email=email)
        except User.DoesNotExist:
            invitee_user = User(username=email, email=email)
            invitee_user.save()

            expert = invitee_user.expert
            expert.first_name  = self.cleaned_data.get('first_name', '')
            expert.second_name = self.cleaned_data.get('second_name', '')
            expert.last_name   = self.cleaned_data.get('last_name', '')
            expert.save()

        initiator = self.request.user.expert
        invitee = invitee_user.expert
        discussion = self.cleaned_data["discussion"]
        try:
            invite = Invite.objects.get(invitee=invitee, discussion=discussion, status=Invite.NEW)
        except Invite.DoesNotExist:
            code = User.objects.make_random_password(
                length=32, allowed_chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789')
            invite = Invite(initiator=initiator, invitee=invitee, discussion=discussion, code=code)
            invite.save()

        return invite

    class Meta:
        model = Invite
        fields = ("discussion",)


class CommentForm(forms.ModelForm):
    def __init__(self, request, instance=None):
        super(CommentForm, self).__init__(request and request.POST, request and request.FILES, instance=instance)
        self.request = request

    def clean_discussion(self):
        discussion = self.cleaned_data['discussion']
        if not self.request.user.has_perm('can_comment', discussion):
            raise forms.ValidationError('Can not comment this discussion')
        return discussion

    def clean_parent(self):
        discussion = self.cleaned_data['discussion']
        parent = self.cleaned_data['parent']
        if parent and parent.discussion != discussion:
            raise forms.ValidationError('Specified parent does not belong to the discussion')
        return parent

    def save(self, commit=True):
        comment = super(forms.ModelForm, self).save(commit=False)
        comment.author = self.request.user.expert
        if commit:
            comment.save()
        return comment

    class Meta:
        model = Comment
        fields = ("discussion", "parent", "text")


class TransferForm(forms.ModelForm):
    email = forms.EmailField(label=_("E-mail"), max_length=75)

    def __init__(self, request):
        super(TransferForm, self).__init__(request and request.POST)
        self.request = request
        self.fields["dicoms"].queryset = Dicom.objects.filter(owner=request.user.expert)

    def clean_dicoms(self):
        dicoms = self.cleaned_data["dicoms"]
        if len(dicoms) == 0:
            raise forms.ValidationError('At least one dicom should be specified')
        for dicom in dicoms:
            if dicom.owner != self.request.user.expert:
                raise forms.ValidationError('Dicom does not belong to the logged user')
            if Transfer.objects.exclude(status=Transfer.DECLINED).filter(dicoms=dicom).exists():
                raise forms.ValidationError('There is already transfer with this dicom')

        return dicoms

    def save(self, commit=True):
        email = self.cleaned_data["email"]
        try:
            recipient_user = User.objects.get(email=email)
        except User.DoesNotExist:
            recipient_user = User(username=email, email=email)
            recipient_user.save()

            expert = recipient_user.expert
            expert.first_name  = self.cleaned_data.get('first_name', '')
            expert.second_name = self.cleaned_data.get('second_name', '')
            expert.last_name   = self.cleaned_data.get('last_name', '')
            expert.save()

        sender = self.request.user.expert
        recipient = recipient_user.expert
        dicoms = self.cleaned_data["dicoms"]
        description = self.cleaned_data["description"]
        try:
            transfer = Transfer.objects.exclude(status=Transfer.DECLINED).get(recipient=recipient, dicoms=dicoms)
        except Transfer.DoesNotExist:
            code = User.objects.make_random_password(
                length=32, allowed_chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789')
            transfer = Transfer.objects.create(
                sender=sender, recipient=recipient, description=description, code=code)
            for dicom in dicoms:
                transfer.dicoms.add(dicom)

        return transfer

    class Meta:
        model = Transfer
        fields = ("description", "dicoms")
