from datetime import datetime
import os
import os.path
import re
import shutil
import subprocess
import zipfile

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from medassist.models import *


class Command(BaseCommand):
    help = 'Works with uploaded DICOM files'

    def add_arguments(self, parser):
        parser.add_argument('--extract',
            action = 'store_true',
            dest = 'extract',
            default = False,
            help = 'Extract images and meta information from uploaded DICOM files')
        parser.add_argument('--expire',
            action = 'store_true',
            dest = 'expire',
            default = False,
            help = 'Remove expired DICOM files')

    def handle(self, extract=False, expire=False, **options):
        print options
        if extract:
            self.extract()
        if expire:
            self.expire()

    def extract(self):
        TAG_LINE = re.compile(r'(?P<tag_id>\(\w+,\w+\))\s+(?P<tag_code>\w+)\s+\[(?P<tag_value>[^\]]*)\]\s+\#\s+\d+,\s+\d+\s+(?P<tag_name>.*)')
        CUT_FROM = len(os.path.normpath(settings.MEDIA_ROOT)) + 1

        for dicom in Dicom.objects.filter(status__in=[Dicom.WAITING, Dicom.PREPARING]):
            if dicom.status != Dicom.PREPARING:
                dicom.status = Dicom.PREPARING
                dicom.save()

            file_path = os.path.join(settings.MEDIA_ROOT, dicom.file.name)
            file_name = os.path.basename(file_path)
            owner_dir = os.path.dirname(file_path)
            dicom_dir = os.path.join(owner_dir, str(dicom.id))
            new_file_path = os.path.join(dicom_dir, file_name)

            if not os.path.exists(dicom_dir):
                os.mkdir(dicom_dir)

            if not os.path.isdir(dicom_dir):
                pass # mark as error, send message and go to next dicom

            if not os.path.isfile(file_path):
                pass # mark as error, send message and go to next dicom

            # Unzip if needed
            if file_path.lower().endswith('.zip'):
                zip_ref = zipfile.ZipFile(file_path, 'r')
                zip_ref.extractall(dicom_dir)
                zip_ref.close()
            else:
                if os.path.exists(new_file_path):
                    pass # mark as error, send message and go to next dicom
                else:
                    shutil.copy(file_path, new_file_path)

            # Extract images and meta
            first_image = True
            for root, subdirs, files in os.walk(dicom_dir):
                files.sort()
                for file in files:
                    filename = os.path.join(root, file)
                    jpg_filename = filename + '.med.jpg'
                    tag_filename = filename + '.med.tag'
                    # Extract images
                    subprocess.call(['/usr/bin/dcmj2pnm', '+oj', '--use-window', '1', filename, jpg_filename])
                    # Extract meta
                    with open(tag_filename, "w+") as output:
                        subprocess.call(['/usr/bin/dcmdump', filename], stdout=output)
                    # Store file
                    dicom_file = DicomFile()
                    dicom_file.dicom = dicom
                    dicom_file.file.name = jpg_filename[CUT_FROM:]
                    with open(tag_filename, "r") as input:
                        lines = input.read().splitlines()
                        for line in lines:
                            if 'ImageOrientationPatient' in line:
                                m = TAG_LINE.match(line)
                                if m:
                                    tag_name = m.group('tag_name')
                                    # TODO: optimize
                                    if tag_name == 'ImageOrientationPatient':
                                        dicom_file.orientation = m.group('tag_value')
                            if 'SeriesDescription' in line:
                                m = TAG_LINE.match(line)
                                if m:
                                    tag_name = m.group('tag_name')
                                    # TODO: optimize
                                    if tag_name == 'SeriesDescription':
                                        dicom_file.series_description = m.group('tag_value')
                        if first_image:
                            for line in lines:
                                m = TAG_LINE.match(line)
                                if m:
                                    tag_name = m.group('tag_name')
                                    if tag_name == 'StudyDate':
                                        dicom.study_date = self.parse_date(m.group('tag_value'))
                                    elif tag_name == 'PatientID':
                                        dicom.patient_id = m.group('tag_value')
                                    elif tag_name == 'PatientName':
                                        if not dicom.patient_name:
                                            dicom.patient_name = m.group('tag_value')
                                    elif tag_name == 'PatientSex':
                                        dicom.patient_sex = m.group('tag_value')
                                    elif tag_name == 'PatientBirthDate':
                                        dicom.patient_birthday = self.parse_date(m.group('tag_value'))
                                    elif tag_name == 'PatientAge':
                                        dicom.patient_age = m.group('tag_value')
                                    elif tag_name == 'PatientWeight':
                                        dicom.patient_weight = int(m.group('tag_value'))
                            dicom.save()

                            first_image = False
                    dicom_file.save()
                    # Remove DICOM file
                    os.remove(filename)


            # Mark as ready
            dicom.status = Dicom.READY
            dicom.save()

    def expire(self):
        pass

    def parse_date(self, s):
        year    = int(s[:4])
        month   = int(s[4:6])
        day     = int(s[6:])
        return datetime(year, month, day)
