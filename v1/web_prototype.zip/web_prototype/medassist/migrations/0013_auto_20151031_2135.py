# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('medassist', '0012_auto_20151031_2112'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='discussion',
            options={'verbose_name': 'Discussion', 'verbose_name_plural': 'Discussions', 'permissions': (('can_manage', 'Can manage a discussion'), ('can_view', 'Can view a discussion'), ('can_comment', 'Can comment a discussion'))},
        ),
    ]
