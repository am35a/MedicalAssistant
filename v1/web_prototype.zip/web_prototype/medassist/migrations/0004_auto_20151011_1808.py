# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('medassist', '0003_auto_20150910_2002'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='discussion',
            name='close_status',
        ),
        migrations.AddField(
            model_name='dicom',
            name='downloadable',
            field=models.BooleanField(default=datetime.datetime(2015, 10, 11, 18, 8, 20, 556629)),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='discussion',
            name='closed_at',
            field=models.DateField(null=True, verbose_name='Closed', blank=True),
        ),
        migrations.AddField(
            model_name='discussion',
            name='created_at',
            field=models.DateField(default=datetime.datetime(2015, 10, 11, 18, 6, 33, 551974), verbose_name='Created'),
        ),
        migrations.AddField(
            model_name='discussion',
            name='description',
            field=models.TextField(blank=True),
        ),
        migrations.AddField(
            model_name='discussion',
            name='dicom',
            field=models.ForeignKey(default=None, to='medassist.Dicom'),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='discussion',
            name='end_date',
            field=models.DateField(default=datetime.datetime(2015, 10, 25, 18, 6, 33, 552050)),
        ),
        migrations.AddField(
            model_name='discussion',
            name='name',
            field=models.CharField(default='', max_length=255),
            preserve_default=False,
        ),
    ]
