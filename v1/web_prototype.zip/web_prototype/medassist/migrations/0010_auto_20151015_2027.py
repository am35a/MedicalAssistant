# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('medassist', '0009_merge'),
    ]

    operations = [
        migrations.CreateModel(
            name='Invite',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('invited_at', models.DateTimeField(auto_now=True, verbose_name='Invited at')),
                ('decided_at', models.DateTimeField(null=True, verbose_name='Decided at', blank=True)),
                ('status', models.IntegerField(default=1, verbose_name='Status', choices=[(1, b'New'), (2, b'Accepted'), (3, b'Declined')])),
            ],
        ),
        migrations.AlterField(
            model_name='discussion',
            name='created_at',
            field=models.DateField(auto_now=True, verbose_name='Created'),
        ),
        migrations.AlterField(
            model_name='discussion',
            name='end_date',
            field=models.DateField(default=datetime.datetime(2015, 10, 29, 20, 27, 17, 251021)),
        ),
        migrations.AddField(
            model_name='invite',
            name='discussion',
            field=models.ForeignKey(verbose_name='Discussion', to='medassist.Discussion'),
        ),
        migrations.AddField(
            model_name='invite',
            name='initiator',
            field=models.ForeignKey(related_name='sent_invites', verbose_name='Initiator', to='medassist.Expert'),
        ),
        migrations.AddField(
            model_name='invite',
            name='invitee',
            field=models.ForeignKey(related_name='received_invites', verbose_name='Invitee', to='medassist.Expert'),
        ),
    ]
