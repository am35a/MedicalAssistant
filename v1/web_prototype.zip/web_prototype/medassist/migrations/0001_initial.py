# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings
import medassist.models


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Dicom',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=255, blank=True)),
                ('file', models.FileField(upload_to=medassist.models.dicom_uploader)),
            ],
            options={
                'verbose_name': 'Dicom',
                'verbose_name_plural': 'Dicoms',
            },
        ),
        migrations.CreateModel(
            name='Discussion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('visibility', models.CharField(max_length=8, choices=[(b'private', '\u041f\u0440\u0438\u0432\u0430\u0442\u043d\u044b\u0435'), (b'public', '\u041f\u0443\u0431\u043b\u0438\u0447\u043d\u044b\u0435')])),
                ('close_status', models.CharField(max_length=8, choices=[(b'owner', '\u0417\u0430\u043a\u0440\u044b\u0442\u043e \u0432\u043b\u0430\u0434\u0435\u043b\u044c\u0446\u0435\u043c'), (b'expiry', '\u0418\u0441\u0442\u0435\u0447\u0435\u043d\u0438\u0435 \u0441\u0440\u043e\u043a\u0430 \u0430\u043a\u0442\u0443\u0430\u043b\u044c\u043d\u043e\u0441\u0442\u0438')])),
            ],
            options={
                'verbose_name': 'Discussion',
                'verbose_name_plural': 'Discussions',
            },
        ),
        migrations.CreateModel(
            name='Expert',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('place_of_work', models.CharField(default=b'', max_length=500)),
                ('degree', models.CharField(default=b'', max_length=255)),
                ('post', models.CharField(default=b'', max_length=255)),
                ('name', models.CharField(max_length=255)),
                ('speciality', models.CharField(max_length=255)),
                ('email', models.EmailField(max_length=254)),
                ('phone', models.CharField(max_length=16, null=True, blank=True)),
                ('is_private_phone', models.BooleanField(default=True)),
                ('registration_key', models.CharField(default=b'', max_length=64, blank=True)),
                ('contact_list', models.ManyToManyField(related_name='contact_list_rel_+', to='medassist.Expert', blank=True)),
                ('user', models.OneToOneField(to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name': 'Expert',
                'verbose_name_plural': 'Experts',
            },
        ),
        migrations.CreateModel(
            name='Notification',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'verbose_name': 'Notification',
                'verbose_name_plural': 'Notifications',
            },
        ),
        migrations.AddField(
            model_name='discussion',
            name='owner',
            field=models.ForeignKey(to='medassist.Expert'),
        ),
        migrations.AddField(
            model_name='dicom',
            name='owner',
            field=models.ForeignKey(to='medassist.Expert'),
        ),
    ]
