# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import medassist.models


class Migration(migrations.Migration):

    dependencies = [
        ('medassist', '0011_auto_20151026_2042'),
    ]

    operations = [
        migrations.CreateModel(
            name='Participant',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('joined_at', models.DateTimeField(auto_now=True, verbose_name='Joined')),
                ('left_at', models.DateTimeField(null=True, verbose_name='Left', blank=True)),
                ('is_interesting', models.BooleanField(default=False)),
            ],
        ),
        migrations.AlterField(
            model_name='dicom',
            name='downloadable',
            field=models.BooleanField(default=False),
        ),
        migrations.AlterField(
            model_name='discussion',
            name='end_date',
            field=models.DateField(default=medassist.models.after_two_weeks),
        ),
        migrations.AlterField(
            model_name='discussion',
            name='visibility',
            field=models.CharField(max_length=8, choices=[(b'private', 'Private'), (b'public', 'Public')]),
        ),
        migrations.AddField(
            model_name='participant',
            name='discussion',
            field=models.ForeignKey(to='medassist.Discussion'),
        ),
        migrations.AddField(
            model_name='participant',
            name='expert',
            field=models.ForeignKey(to='medassist.Expert'),
        ),
    ]
