# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('medassist', '0015_comment'),
    ]

    operations = [
        migrations.CreateModel(
            name='Transfer',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('description', models.TextField(blank=True)),
                ('status', models.IntegerField(default=1, verbose_name='Status', choices=[(1, b'New'), (2, b'Accepted'), (3, b'Declined')])),
                ('created_at', models.DateField(auto_now=True, verbose_name='Created')),
                ('code', models.CharField(default=b'', max_length=64, blank=True)),
                ('dicoms', models.ManyToManyField(to='medassist.Dicom')),
                ('recipient', models.ForeignKey(related_name='received_transfers', to='medassist.Expert')),
                ('sender', models.ForeignKey(related_name='sent_transfers', to='medassist.Expert')),
            ],
        ),
    ]
