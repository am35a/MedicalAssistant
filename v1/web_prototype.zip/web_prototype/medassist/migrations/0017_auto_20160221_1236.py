# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import datetime
import medassist.models


class Migration(migrations.Migration):

    dependencies = [
        ('medassist', '0016_transfer'),
    ]

    operations = [
        migrations.AddField(
            model_name='dicom',
            name='created_at',
            field=models.DateField(default=datetime.datetime(2016, 2, 21, 12, 36, 45, 713774), verbose_name='Created', auto_now=True),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='dicom',
            name='end_date',
            field=models.DateField(default=medassist.models.after_two_weeks),
        ),
        migrations.AddField(
            model_name='dicom',
            name='status',
            field=models.IntegerField(default=1, verbose_name='Status', choices=[(1, b'Waiting'), (2, b'Preparing'), (3, b'Ready'), (4, b'Obsolete')]),
        ),
        migrations.AlterField(
            model_name='comment',
            name='author',
            field=models.ForeignKey(related_name='comments', to='medassist.Expert'),
        ),
        migrations.AlterField(
            model_name='dicom',
            name='owner',
            field=models.ForeignKey(related_name='dicoms', to='medassist.Expert'),
        ),
        migrations.AlterField(
            model_name='dicom',
            name='patient',
            field=models.CharField(max_length=512, null=True, blank=True),
        ),
        migrations.AlterField(
            model_name='discussion',
            name='owner',
            field=models.ForeignKey(related_name='discussions', to='medassist.Expert'),
        ),
        migrations.DeleteModel(
            name='Patient',
        ),
    ]
