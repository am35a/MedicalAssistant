# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('medassist', '0004_auto_20151011_1808'),
    ]

    operations = [
        migrations.AlterField(
            model_name='discussion',
            name='created_at',
            field=models.DateField(default=datetime.datetime.now, verbose_name='Created'),
        ),
        migrations.AlterField(
            model_name='discussion',
            name='dicom',
            field=models.ForeignKey(to='medassist.Dicom', null=True),
        ),
        migrations.AlterField(
            model_name='discussion',
            name='end_date',
            field=models.DateField(default=datetime.datetime(2015, 10, 29, 9, 15, 54, 534210)),
        ),
    ]
