# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('medassist', '0014_auto_20151031_2153'),
    ]

    operations = [
        migrations.CreateModel(
            name='Comment',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('text', models.TextField(verbose_name='Text')),
                ('commented_at', models.DateTimeField(auto_now=True, verbose_name='Commented')),
                ('author', models.ForeignKey(to='medassist.Expert')),
                ('discussion', models.ForeignKey(related_name='comments', to='medassist.Discussion')),
                ('parent', models.ForeignKey(related_name='children', blank=True, to='medassist.Comment', null=True)),
            ],
        ),
    ]
