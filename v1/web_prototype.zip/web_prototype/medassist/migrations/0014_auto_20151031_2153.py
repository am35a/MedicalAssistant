# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('medassist', '0013_auto_20151031_2135'),
    ]

    operations = [
        migrations.AlterField(
            model_name='expert',
            name='first_name',
            field=models.CharField(max_length=255, blank=True),
        ),
        migrations.AlterField(
            model_name='expert',
            name='last_name',
            field=models.CharField(max_length=255, blank=True),
        ),
        migrations.AlterField(
            model_name='expert',
            name='second_name',
            field=models.CharField(max_length=255, blank=True),
        ),
    ]
