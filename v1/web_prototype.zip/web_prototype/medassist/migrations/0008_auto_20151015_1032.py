# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('medassist', '0007_auto_20151015_1029'),
    ]

    operations = [
        migrations.AlterField(
            model_name='discussion',
            name='created_at',
            field=models.DateField(auto_now=True, verbose_name='Created'),
        ),
        migrations.AlterField(
            model_name='discussion',
            name='end_date',
            field=models.DateField(default=datetime.datetime(2015, 10, 29, 10, 32, 9, 269422)),
        ),
    ]
