# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('medassist', '0002_auto_20150831_1552'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='expert',
            name='name',
        ),
        migrations.AddField(
            model_name='expert',
            name='first_name',
            field=models.CharField(default='', max_length=255),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='expert',
            name='last_name',
            field=models.CharField(default='', max_length=255),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='expert',
            name='second_name',
            field=models.CharField(default='', max_length=255),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name='expert',
            name='user',
            field=models.OneToOneField(related_name='expert', to=settings.AUTH_USER_MODEL),
        ),
    ]
