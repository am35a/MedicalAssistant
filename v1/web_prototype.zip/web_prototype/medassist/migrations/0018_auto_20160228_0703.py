# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('medassist', '0017_auto_20160221_1236'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='dicom',
            name='name',
        ),
        migrations.AddField(
            model_name='dicom',
            name='description',
            field=models.TextField(blank=True),
        ),
    ]
