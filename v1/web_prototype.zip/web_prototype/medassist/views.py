from collections import defaultdict

from django.shortcuts import render_to_response

from django.http import HttpResponseRedirect, Http404
from django.contrib.auth import authenticate, login, logout, forms as auth_forms
from django.contrib.auth.decorators import login_required
from django.utils.encoding import force_text
from django.utils.http import urlsafe_base64_decode

from rest_framework import viewsets, renderers, permissions, response
from rest_framework.decorators import api_view, renderer_classes, parser_classes
from rest_framework.parsers import JSONParser, FileUploadParser, FormParser, MultiPartParser
from rest_framework.filters import OrderingFilter
import rest_framework.exceptions as rest_exc

from .forms import *
from .serializers import *
from .utils import *


def go(request, template, context=None):
    return render_to_response('html/' + template + '.html', context_instance=RequestContext(request, context))


def do_index(request):
    return go(request, 'index')


def do_registration(request):
    return go(request, 'registration', {
        'registration_form': RegistrationForm(request),
    })


def do_activate(request, activation_key):
    try:
        expert = Expert.objects.get(registration_key=activation_key)
        user = expert.user

        # generate and send mail
        password = User.objects.make_random_password()
        user.set_password(password)
        user.save()
        send_mail_to_user(request, user, 'send_password', {'password': password})

        # reset registration key
        expert.registration_key = "verified"
        expert.save()

        # login and show first page
        user = authenticate(username=user.username, password=password)
        login(request, user)
        return go(request, 'activation_key_done')
    except Expert.DoesNotExist:
        return go(request, 'activation_key_invalid')


def do_register(request):
    form = RegistrationForm(request)
    context = {}
    if not form.is_valid():
        context = {
            'registration_form': RegistrationForm(request),
            'reg_error': form.errors.as_data(),
            'well_done': False,
        }
        return go(request, 'index', context)

    user = form.save()
    context['user'] = user
    context['well_done'] = True

    return go(request, 'index', context)


def do_login(request):
    context = {}
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)

        if user is not None:
            if user.is_active:
                login(request, user)
                return HttpResponseRedirect('/my/')
            else:
                context['enter_error'] = "Invalid login or/and password"
        else:
            context['enter_error'] = "Invalid login or/and password."

    return render_to_response('html/index.html', context, context_instance=RequestContext(request))


def do_logout(request):
    logout(request)
    return HttpResponseRedirect('/login/')


@login_required(login_url='/login/')
def my_view(request):
    return go(request, 'main')


@login_required(login_url='/login/')
def dicom_new(request):
    return go(request, 'dicom_form', {'form': DicomForm(request)})


@login_required(login_url='/login/')
def dicom_create(request):
    form = DicomForm(request)
    if not form.is_valid():
        return go(request, 'dicom_form', {'form': form})

    form.save()

    # TODO: go to dicom list
    return go(request, 'dicom_added')


@login_required(login_url='/login/')
def discussion_view(request, discussion_id):
    try:
        discussion = Discussion.objects.get(id=discussion_id)
    except Discussion.DoesNotExist:
        raise Http404()

    if not request.user.has_perm('can_view', discussion):
        return go(request, 'no_rights')

    return go(request, 'discussion_view', {
        'discussion': discussion,
        # TODO: use template tags/filters?
        'can_change': request.user.has_perm('can_manage', discussion),
        'can_comment': request.user.has_perm('can_comment', discussion),
    })


@login_required(login_url='/login/')
def comment_create(request):
    form = CommentForm(request)
    if not form.is_valid():
        # TODO: what should we do if there is no cleaned discussion?
        discussion = form.cleaned_data['discussion']
        return go(request, 'discussion_view', {
            'discussion': discussion,
            'comment_form': form,
            'can_change': request.user.has_perm('can_manage', discussion),
            'can_comment': request.user.has_perm('can_comment', discussion),
        })

    comment = form.save()

    return HttpResponseRedirect('/discussion/%s' % comment.discussion.id)


@login_required(login_url='/login/')
def discussion_new(request):
    return go(request, 'discussion_form', {'form': DiscussionForm(request)})


@login_required(login_url='/login/')
def discussion_create(request):
    form = DiscussionForm(request)
    if not form.is_valid():
        return go(request, 'discussion_form', {'form': form})

    discussion = form.save()
    form.save_m2m()

    assign_perm(request, 'can_manage', discussion)
    assign_perm(request, 'can_view', discussion)
    assign_perm(request, 'can_comment', discussion)

    # TODO: go to discussion list
    return go(request, 'discussion_added')


@login_required(login_url='/login/')
def invite_new(request):
    return go(request, 'invite_form', {'form': InviteForm(request)})


@login_required(login_url='/login/')
def invite_create(request):
    form = InviteForm(request)
    if not form.is_valid():
        return go(request, 'invite_form', {'form': form})

    invite = form.save()
    send_mail_to_user(request, invite.invitee.user, 'invite', {'invite': invite})

    return go(request, 'invite_sent')


def invite_accept(request, code):
    try:
        invite = Invite.objects.get(code=code)
    except Invite.DoesNotExist:
        return go(request, 'invite_notfound')

    invitee = invite.invitee
    user = invitee.user
    discussion = invite.discussion

    if invite.status == Invite.DECLINED:
        return go(request, 'invite_notfound')

    if invite.status == Invite.ACCEPTED:
        if request.user.is_authenticated() and request.user.id == user.id:
            return HttpResponseRedirect('/discussion/%s' % discussion.id)
        return go(request, 'invite_notfound')

    is_new = not user.password
    if is_new:
        # generate password
        password = User.objects.make_random_password(length=8)
        user.set_password(password)
        user.save()

        # send password to a user
        send_mail_to_user(request, user, 'send_password', {'password': password})

        # authenticate new user
        user = authenticate(username=user.username, password=password)

    # login user
    user.backend = 'django.contrib.auth.backends.ModelBackend'
    login(request, user)

    assign_perm(request, 'can_view', discussion)
    assign_perm(request, 'can_comment', discussion)

    # Prevent to create duplicate participant
    if not Participant.objects.filter(expert=invitee, discussion=discussion).exists():
        participant = Participant(expert=invitee, discussion=discussion)
        participant.save()

    invite.status = Invite.ACCEPTED
    invite.save()

    # TODO: add a user to friends of the discussion's owner

    if not is_new:
        return HttpResponseRedirect('/discussion/%s' % discussion.id)

    return go(request, 'first_page', {'next_page': '/discussion/%s' % discussion.id})


def invite_decline(request, code):
    try:
        invite = Invite.objects.get(code=code, status=Invite.NEW)
    except Invite.DoesNotExist:
        return go(request, 'invite_notfound')

    invite.status = Invite.DECLINED
    invite.save()

    return go(request, 'invite_declined')


@login_required(login_url='/login/')
def transfer_new(request):
    return go(request, 'transfer_form', {'form': TransferForm(request)})


@login_required(login_url='/login/')
def transfer_create(request):
    form = TransferForm(request)
    if not form.is_valid():
        return go(request, 'transfer_form', {'form': form})

    transfer = form.save()

    send_mail_to_user(request, transfer.recipient.user, 'transfer', {'transfer': transfer})

    return go(request, 'transfer_sent')


def transfer_accept(request, code):
    try:
        transfer = Transfer.objects.get(code=code)
    except Transfer.DoesNotExist:
        return go(request, 'transfer_notfound')

    recipient = transfer.recipient
    user = recipient.user

    if transfer.status != Transfer.NEW:
        return go(request, 'invite_notfound')

    is_new = not user.password
    if is_new:
        # generate password
        password = User.objects.make_random_password(length=8)
        user.set_password(password)
        user.save()

        # send password to a user
        send_mail_to_user(request, user, 'send_password', {'password': password})

        # authenticate new user
        user = authenticate(username=user.username, password=password)

    # login user
    user.backend = 'django.contrib.auth.backends.ModelBackend'
    login(request, user)

    for dicom in transfer.dicoms.all():
        dicom.owner = recipient
        dicom.save()

    transfer.status = Transfer.ACCEPTED
    transfer.save()

    # create notification for sender
    Notification.objects.create(
        owner=transfer.sender, type=Notification.TRANSFER_ACCEPTED, transfer=transfer)

    if not is_new:
        return go(request, 'transfer_accepted', {'transfer': transfer})

    return go(request, 'first_page', {'next_page': '/dicoms/'})


def transfer_decline(request, code):
    try:
        transfer = Transfer.objects.get(code=code, status=Transfer.NEW)
    except Transfer.DoesNotExist:
        return go(request, 'transfer_notfound')

    transfer.status = Transfer.DECLINED
    transfer.save()

    # create notification for sender
    Notification.objects.create(
        owner=transfer.sender, type=Notification.TRANSFER_DECLINED, transfer=transfer)

    return go(request, 'transfer_declined')

#
# REST API View Sets
#


class UTF8JSONRenderer(renderers.JSONRenderer):
    charset = 'UTF-8'


class IsExpert(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and hasattr(request.user, 'expert')

    def has_object_permission(self, request, view, obj):
        return request.user and hasattr(request.user, 'expert')


class DicomViewSet(viewsets.ModelViewSet):
    model = Dicom
    serializer_class = DicomSerializer
    renderer_classes = (UTF8JSONRenderer,)
    parser_classes = (FormParser, MultiPartParser)
    permission_classes = (IsExpert,)
    filter_backends = (OrderingFilter,)

    def get_queryset(self):
        return self.request.user.expert.dicoms.all()

    def perform_create(self, serializer):
        return serializer.save(owner=self.request.user.expert)


class DicomFileViewSet(viewsets.ModelViewSet):
    model = DicomFile
    serializer_class = DicomFileSerializer
    renderer_classes = (UTF8JSONRenderer,)
    parser_classes = (FormParser, MultiPartParser)
    permission_classes = (IsExpert,)
    filter_backends = (OrderingFilter,)

    def get_queryset(self):
        queryset = DicomFile.objects.filter(dicom__owner__user=self.request.user)
        dicom_id = self.request.query_params.get('dicom_id', None)
        if dicom_id is not None:
            queryset = queryset.filter(dicom__id=dicom_id)
        series_description = self.request.query_params.get('series_description', None)
        if series_description is not None:
            queryset = queryset.filter(series_description=series_description)
        return queryset.order_by('id')


class TransferViewSet(viewsets.ModelViewSet):
    model = Transfer
    serializer_class = TransferSerializer
    renderer_classes = (UTF8JSONRenderer,)
    permission_classes = (IsExpert,)
    filter_backends = (OrderingFilter,)

    def get_queryset(self):
        queryset = Transfer.objects.filter(sender__user=self.request.user)
        return queryset.order_by('id')

    def perform_create(self, serializer):
        transfer = serializer.save(sender=self.request.user.expert)
        send_mail_to_user(self.request, transfer.recipient.user, 'transfer', {'transfer': transfer})


class NotificationViewSet(viewsets.ReadOnlyModelViewSet):
    model = Notification
    serializer_class = NotificationSerializer
    renderer_classes = (UTF8JSONRenderer,)
    permission_classes = (IsExpert,)
    filter_backends = (OrderingFilter,)

    def get_queryset(self):
        queryset = Notification.objects.filter(owner__user=self.request.user)
        return queryset.order_by('-id')


class DiscussionViewSet(viewsets.ModelViewSet):
    model = Discussion
    serializer_class = DiscussionSerializer
    renderer_classes = (UTF8JSONRenderer,)
    permission_classes = (IsExpert,)

    def get_queryset(self):
        return self.request.user.expert.discussions.all()

    def perform_create(self, serializer):
        return serializer.save(owner=self.request.user.expert)


class CommentViewSet(viewsets.ModelViewSet):
    model = Comment
    serializer_class = CommentSerializer
    renderer_classes = (UTF8JSONRenderer,)
    permission_classes = (IsExpert,)

    def get_queryset(self):
        comments = self.request.user.expert.comments.order_by('commented_at')

        discussion_id = self.request.query_params.get('discussion_id')
        if discussion_id:
            comments = comments.filter(discussion__id=discussion_id)

        return comments.all()

    def perform_create(self, serializer):
        return serializer.save(author=self.request.user.expert)


@api_view(['POST'])
@parser_classes([JSONParser])
@renderer_classes([UTF8JSONRenderer])
def api_reset_password(request):
    form = auth_forms.PasswordResetForm(request.data)
    if not form.is_valid():
        raise rest_exc.ValidationError(form.errors)
    form.save(request=request,
        subject_template_name='mail/password_reset.subject',
        email_template_name='mail/password_reset.body',)
    return response.Response({"success": True})


def password_reset_complete(request):
    return HttpResponseRedirect('/my/')


@api_view(['POST'])
@parser_classes([JSONParser])
@renderer_classes([UTF8JSONRenderer])
def api_user_register(request):
    form = RegistrationForm(request)
    if not form.is_valid():
        return response.Response({"success": False, "errors": form.errors})

    form.save()

    return response.Response({"success": True})


@api_view(['POST'])
@parser_classes([JSONParser])
@renderer_classes([UTF8JSONRenderer])
def api_user_login(request):
    username = request.data.get('username')
    password = request.data.get('password')
    user = authenticate(username=username, password=password)

    error = None
    if user is not None:
        if user.is_active:
            login(request, user)
        else:
            error = "Invalid login or/and password"
    else:
        error = "Invalid login or/and password."

    if error is None:
        return response.Response({"success": True})
    else:
        return response.Response({"success": False, "error": error})

@api_view(['GET'])
@renderer_classes([UTF8JSONRenderer])
def api_dicom_series(request, dicom_id):
    # TODO: check rights
    files = flist(DicomFile.objects.filter(dicom__id=dicom_id))
    files_by_series = defaultdict(list)
    for k, v in flist(files).map(lambda r: (r.series_description, r)):
        files_by_series[k].append(v)

    def mid_file(l):
        return l and l[len(l)/2].file.url or None

    series = flist(files_by_series.keys()).     \
            filter(lambda s: s is not None).    \
            map(lambda s: {'name': s, 'image': mid_file(files_by_series[s]) })

    return response.Response(series)
