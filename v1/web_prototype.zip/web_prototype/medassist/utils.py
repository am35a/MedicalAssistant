from django.core.mail import send_mail
from django.template import RequestContext
from django.template.loader import render_to_string

from guardian.models import UserObjectPermission


def assign_perm(request, perm, obj):
    UserObjectPermission.objects.assign_perm(perm, request.user, obj)


def send_mail_to_user(request, user, template, context=None):
    if not context:
        context = {}

    context['user'] = user
    context['host'] = request.META['HTTP_HOST']

    request_context = RequestContext(request)
    send_mail(
        render_to_string('mail/%s.subject' % template, context, request_context).strip(),
        render_to_string('mail/%s.body' % template, context, request_context),
        None, [user.email])


class flist(list):

    def __init__(self, l):
        list.__init__(self, l)

    def map(self, f):
        return flist(map(f, self[:]))

    def filter(self, f):
        return flist(filter(f, self[:]))
