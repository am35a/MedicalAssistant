from django.conf import settings

from rest_framework import serializers

from .models import *


class DicomSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dicom
        fields = ('id', 'patient_name', 'description', 'downloadable', 'file', 'study_date', 'default_image')
        read_only_fields = ('study_date', 'default_image')


class DicomFileSerializer(serializers.ModelSerializer):
    url = serializers.SerializerMethodField()

    def get_url(self, obj):
        return '%s%s' % (settings.MEDIA_URL, obj.file)

    class Meta:
        model = DicomFile
        fields = ('id', 'url',)
        read_only_fields = ('url',)


class TransferSerializer(serializers.ModelSerializer):
    recipient_email = serializers.EmailField(max_length=75, write_only=True)

    def create(self, validated_data):
        email = validated_data["recipient_email"]
        try:
            recipient_user = User.objects.get(email=email)
        except User.DoesNotExist:
            recipient_user = User(username=email, email=email)
            recipient_user.save()

            expert = recipient_user.expert
            expert.first_name  = validated_data.get('first_name', '')
            expert.second_name = validated_data.get('second_name', '')
            expert.last_name   = validated_data.get('last_name', '')
            expert.save()

        sender = self.context['request'].user.expert
        recipient = recipient_user.expert
        dicoms = validated_data["dicoms"]
        description = validated_data.get("description") or ''

        # create new transfer
        code = User.objects.make_random_password(
            length=32, allowed_chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789')
        transfer = Transfer.objects.create(sender=sender, recipient=recipient, description=description, code=code)
        for dicom in dicoms:
            transfer.dicoms.add(dicom)

        # create new notification
        Notification.objects.create(
            owner=recipient, type=Notification.TRANSFER_RECEIVED, transfer=transfer)

        return transfer

    class Meta:
        model = Transfer
        fields = ('id', 'sender', 'recipient', 'recipient_email', 'description', 'dicoms', 'status', 'created_at')
        read_only_fields = ('id', 'sender', 'recipient', 'description', 'status', 'created_at')


class NotificationSerializer(serializers.ModelSerializer):
    transfer_id = serializers.IntegerField(read_only=True, source='transfer.id')

    class Meta:
        model = Notification
        fields = ('id', 'owner', 'transfer_id', 'type', 'status', 'created_at')
        read_only_fields = ('id', 'owner', 'transfer_id', 'type', 'status', 'created_at')


class DiscussionSerializer(serializers.ModelSerializer):
    owner_id = serializers.IntegerField(read_only=True, source='owner.id')
    owner_name = serializers.CharField(read_only=True, source='owner.name')

    class Meta:
        model = Discussion
        fields = ('id', 'name', 'description', 'created_at', 'owner_id', 'owner_name', 'comment_count')
        read_only_fields = ('created_at', 'owner_id', 'owner_name', 'comment_count')


class CommentSerializer(serializers.ModelSerializer):
    author_id = serializers.PrimaryKeyRelatedField(source='author', read_only=True)
    parent_id = serializers.PrimaryKeyRelatedField(source='parent', queryset=Comment.objects.all(), required=False)
    discussion_id = serializers.PrimaryKeyRelatedField(source='discussion', queryset=Discussion.objects.all())
    author_name = serializers.CharField(read_only=True, source='author.name')

    def update(self, instance, validated_data):
        validated_data.pop('discussion_id')
        validated_data.pop('parent_id')
        validated_data.pop('author_id')
        return super(CommentSerializer, self).update(instance, validated_data)

    class Meta:
        model = Comment
        fields = ('id', 'text', 'commented_at', 'discussion_id', 'parent_id', 'author_id', 'author_name')
        read_pnly_fields = ('id', 'commented_at', 'author_id', 'author_name')
