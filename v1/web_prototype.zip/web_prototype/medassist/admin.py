from django.contrib import admin
from medassist.models import *


admin.site.register(Expert)
#admin.site.register(ContactList)
admin.site.register(Dicom)
admin.site.register(Discussion)
